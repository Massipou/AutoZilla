# The scripts in this direcoty will be run by run-parts comamnd AFTER ocs-sr starts. 
# //NOTE//:
# (1) You need to enable the option "-o1" otherwise it won't work.
# (2) The scripts here is nothing to do with the option "-p" or "--postaction" of ocs-sr, and they will be run before that assigned in -p or --postaction."
